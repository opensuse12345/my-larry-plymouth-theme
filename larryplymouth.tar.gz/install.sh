sudo cp -r larryplymouth /usr/share/plymouth/themes
sudo plymouth-set-default-theme larryplymouth
