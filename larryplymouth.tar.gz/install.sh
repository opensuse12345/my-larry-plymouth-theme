sudo cp -r ../larryplymouth /usr/share/plymouth/themes
sudo rm -rf /usr/share/plymouth/themes/larryplymouth/install.sh
sudo plymouth-set-default-theme larryplymouth
